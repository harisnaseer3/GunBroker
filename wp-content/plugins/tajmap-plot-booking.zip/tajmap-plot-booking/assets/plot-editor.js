// TajMap Advanced Plot Editor JavaScript

(function($) {
    'use strict';

    // Global editor state
    let canvas, ctx, image, scale = 1, panX = 0, panY = 0;
    let currentTool = 'select';
    let drawing = false;
    let currentShape = null;
    let selectedPlot = null;
    let plots = [];
    let isFullscreen = false;
    let showGrid = false;
    let snapToGrid = false;
    let gridSize = 20;
    let history = [];
    let historyIndex = -1;
    let isInitialized = false;
    
    // Global base map image state (for canvas background)
    let globalBaseMapImage = null;
    let globalBaseMapTransform = {
        x: 0,
        y: 0,
        scale: 1,
        rotation: 0,
        width: 0,
        height: 0
    };
    let isTransformingGlobalBaseMap = false;
    let transformHandle = null;
    let globalBaseMapImageId = null;

    // Mouse state
    let mouseX = 0, mouseY = 0;
    let startX = 0, startY = 0;
    let isDragging = false;
    let dragOffsetX = 0, dragOffsetY = 0;
    let dragStartX = 0, dragStartY = 0;

    $(document).ready(function() {
        initializePlotEditor();
    });

    function initializePlotEditor() {
        // Prevent multiple initializations
        if (isInitialized) {
            return;
        }

        canvas = $('#plot-editor-canvas')[0];
        
        if (!canvas) {
            console.error('Canvas element not found');
            return;
        }
        
        ctx = canvas.getContext('2d');

        if (!ctx) {
            console.error('Canvas context not available');
            return;
        }

        // Set canvas size
        resizeCanvas();

        // Load global base map image first
        loadGlobalBaseMapImage();

        // Load existing plots from the page data
        loadPlotsData();

        // Bind event listeners
        bindEvents();

        // Initialize tool palette
        initializeToolPalette();

        // Mark as initialized
        isInitialized = true;

        // Draw everything
        drawAll();
    }

    function loadPlotsData() {
        // Try to get plots data from a global variable or data attribute
        if (typeof window.plotEditorPlots !== 'undefined') {
            plots = window.plotEditorPlots;
        } else {
            // Fallback: try to get from data attribute
            const plotsData = $('#plot-editor-canvas').data('plots');
            if (plotsData) {
                plots = plotsData;
            }
        }

        console.log('📊 Loaded plots data:', plots);
        if (plots.length > 0) {
            console.log('📊 Sample plot structure:', plots[0]);
            console.log('📊 Available fields:', Object.keys(plots[0]));
        }

        // Parse coordinates for each plot
        plots.forEach(plot => {
            if (typeof plot.coordinates === 'string') {
                try {
                    plot.points = JSON.parse(plot.coordinates);
                } catch (e) {
                    console.error('Error parsing coordinates for plot:', plot.id);
                    plot.points = [];
                }
            }
        });
    }

    function resizeCanvas() {
        const container = $('.editor-canvas-wrapper');
        if (!container.length) return;

        const rect = container[0].getBoundingClientRect();

        canvas.width = rect.width - 2; // Account for border
        canvas.height = rect.height - 2;

        $('#canvas-info').text(`Canvas: ${canvas.width}x${canvas.height}px`);
        drawAll();
    }

    function bindEvents() {
        // Unbind existing events to prevent duplicates
        if (canvas) {
            $(canvas).off('mousedown mousemove mouseup wheel');
        }
        $('.tool-btn').off('click');
        $('#fullscreen-toggle').off('click');
        $('#zoom-in').off('click');
        $('#zoom-out').off('click');
        $('#fit-view').off('click');
        $('#snap-grid-toggle').off('click');
        $('#show-grid-toggle').off('click');
        $('#undo-btn').off('click');
        $('#clear-btn').off('click');
        $('#save-plot').off('click');
        $('#delete-plot').off('click');
        $('#duplicate-plot').off('click');
        $('#upload-base-image').off('click');
        $('#upload-plot-image').off('click');
        $('#plots-list').off('click');
        $(window).off('resize');

        // Canvas events
        if (canvas) {
            $(canvas).on('mousedown', handleMouseDown);
            $(canvas).on('mousemove', handleMouseMove);
            $(canvas).on('mouseup', handleMouseUp);
            $(canvas).on('dblclick', handleDoubleClick);
            $(canvas).on('wheel', handleMouseWheel);
        } else {
            console.error('Canvas not available for event binding');
        }

        // Tool palette events
        $('.tool-btn').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const tool = $(this).data('tool');
            // Only handle tool selection for buttons with data-tool attribute
            if (tool) {
                selectTool(tool);
            }
        });

        // Control events
        $('#fullscreen-toggle').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            toggleFullscreen();
        });
        $('#zoom-in').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            zoom(1.2);
        });
        $('#zoom-out').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            zoom(0.8);
        });
        $('#fit-view').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            fitToView();
        });
        $('#snap-grid-toggle').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            toggleSnapToGrid();
        });
        $('#show-grid-toggle').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            toggleShowGrid();
        });
        $('#undo-btn').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            undo();
        });
        $('#clear-btn').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            clearAll();
        });

        // Form and button events - ensure single execution per action
        $('#save-plot').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            savePlot(e);
        });
        $('#delete-plot').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const plotId = $('#plot-id').val();
            if (plotId) {
                deletePlot(plotId);
            } else if (selectedPlot) {
                // For unsaved plots, call deletePlot with null ID (it will handle the confirmation)
                deletePlot(null);
            }
        });
        $('#duplicate-plot').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            duplicateSelectedPlot();
        });
        $('#upload-base-image').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            uploadBaseImage();
        });
        $('#upload-plot-image').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            uploadPlotImage();
        });

        // Plot list events (using event delegation)
        $('#plots-list').on('click', '.plot-list-item', function() {
            const plotId = $(this).data('id');
            loadPlot(plotId);
        });

        $('#plots-list').on('click', '.btn-icon.edit', function(e) {
            e.stopPropagation();
            const plotId = $(this).closest('.plot-list-item').data('id');
            loadPlot(plotId);
        });

        $('#plots-list').on('click', '.btn-icon.delete', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const plotId = $(this).closest('.plot-list-item').data('id');
            if (plotId) {
                deletePlot(plotId);
            }
        });
        
        // Sort functionality
        const sortDropdown = $('#plots-sort');
        if (sortDropdown.length > 0) {
            console.log('✅ Sort dropdown found, binding event');
            sortDropdown.on('change', function() {
                const sortBy = $(this).val();
                console.log('🎯 Sort dropdown changed to:', sortBy);
                sortPlots(sortBy);
            });
            
            // Also add click handler for testing
            sortDropdown.on('click', function() {
                console.log('🖱️ Sort dropdown clicked');
            });
        } else {
            console.error('❌ Sort dropdown not found! Retrying in 500ms...');
            // Retry after a short delay in case the element is added dynamically
            setTimeout(() => {
                const retryDropdown = $('#plots-sort');
                if (retryDropdown.length > 0) {
                    console.log('✅ Sort dropdown found on retry, binding event');
                    retryDropdown.on('change', function() {
                        const sortBy = $(this).val();
                        console.log('🎯 Sort dropdown changed to:', sortBy);
                        sortPlots(sortBy);
                    });
                } else {
                    console.error('❌ Sort dropdown still not found after retry');
                }
            }, 500);
        }

        // Plot details panel events
        // (removed) plot details panel events

        // Plot search functionality
        $('#plots-search-input').on('input', function() {
            const searchQuery = $(this).val().toLowerCase();
            filterPlots(searchQuery);
        });

        // Image upload events
        $('#upload-base-image').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            uploadBaseImage();
        });

        $('#upload-plot-image').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            uploadPlotImage();
        });

        $('#transform-base-image').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            toggleBaseImageTransform();
        });

        // Window resize
        $(window).on('resize', resizeCanvas);
        
        // Keyboard events
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' && drawing) {
                cancelDrawing();
            }
        });
    }

    function initializeToolPalette() {
        // Set initial tool
        selectTool('select');
    }

    function selectTool(tool) {
        // Cancel any active drawing when switching tools
        if (drawing && currentShape) {
            finishCurrentShape();
        }
        
        currentTool = tool;
        $('.tool-btn').removeClass('active');
        $(`.tool-btn[data-tool="${tool}"]`).addClass('active');
        
        // Provide specific instructions for each tool
        let statusText = `Tool: ${tool.charAt(0).toUpperCase() + tool.slice(1)}`;
        if (tool === 'vertex' && selectedPlot) {
            statusText += ' - Click and drag vertices to edit';
        } else if (tool === 'vertex' && !selectedPlot) {
            statusText += ' - Select a plot first to edit vertices';
        } else if (tool === 'move' && selectedPlot) {
            statusText += ' - Click and drag to move the entire plot';
        } else if (tool === 'move' && !selectedPlot) {
            statusText += ' - Select a plot first to move it';
        } else if (tool === 'select') {
            statusText += ' - Click on plots to select them';
        } else if (tool === 'polygon') {
            statusText += ' - Click to add points, double-click to finish';
        } else if (tool === 'rectangle') {
            statusText += ' - Click and drag to create rectangle';
        } else if (tool === 'rotate' && selectedPlot) {
            statusText += ' - Click and drag to rotate the selected plot';
        } else if (tool === 'rotate' && !selectedPlot) {
            statusText += ' - Select a plot first to rotate it';
        } else if (tool === 'duplicate-selected' && selectedPlot) {
            statusText += ' - Click to duplicate the selected plot';
        } else if (tool === 'duplicate-selected' && !selectedPlot) {
            statusText += ' - Select a plot first to duplicate it';
        }
        
        $('#editor-status').text(statusText);
    }

    function handleMouseDown(e) {
        const rect = canvas.getBoundingClientRect();
        mouseX = (e.clientX - rect.left - panX) / scale;
        mouseY = (e.clientY - rect.top - panY) / scale;

        if (snapToGrid) {
            mouseX = Math.round(mouseX / gridSize) * gridSize;
            mouseY = Math.round(mouseY / gridSize) * gridSize;
        }

        startX = mouseX;
        startY = mouseY;

        // Check for global base map interaction first (use screen coordinates)
        if (globalBaseMapImage && isTransformingGlobalBaseMap) {
            const screenX = e.clientX - rect.left;
            const screenY = e.clientY - rect.top;
            
            const handle = getGlobalBaseMapTransformHandle(screenX, screenY);
            if (handle) {
                isTransformingGlobalBaseMap = true;
                transformHandle = handle;
                isDragging = true;
                dragStartX = e.clientX;
                dragStartY = e.clientY;
                return;
            } else if (isPointInGlobalBaseMap(screenX, screenY)) {
                isTransformingGlobalBaseMap = true;
                transformHandle = 'move';
                isDragging = true;
                dragStartX = e.clientX;
                dragStartY = e.clientY;
                return;
            }
        }

        switch (currentTool) {
            case 'polygon':
                if (!drawing) {
                    startPolygon();
                } else {
                    addPolygonPoint();
                }
                break;
            case 'rectangle':
                startRectangle();
                break;
            case 'select':
                selectShape();
                break;
            case 'vertex':
                editVertices();
                break;
            case 'move':
                startMove();
                break;
            case 'rotate':
                startRotate();
                break;
            case 'duplicate-selected':
                duplicateSelectedPlot();
                break;
        }
    }

    function handleMouseMove(e) {
        const rect = canvas.getBoundingClientRect();
        mouseX = (e.clientX - rect.left - panX) / scale;
        mouseY = (e.clientY - rect.top - panY) / scale;

        if (snapToGrid) {
            mouseX = Math.round(mouseX / gridSize) * gridSize;
            mouseY = Math.round(mouseY / gridSize) * gridSize;
        }

        // Handle global base map transformation
        if (isTransformingGlobalBaseMap && transformHandle) {
            const deltaX = e.clientX - dragStartX;
            const deltaY = e.clientY - dragStartY;
            transformGlobalBaseMap(transformHandle, deltaX, deltaY);
            dragStartX = e.clientX;
            dragStartY = e.clientY;
            return;
        }

        // Update cursor for global base map interaction
        if (globalBaseMapImage && isTransformingGlobalBaseMap) {
            const screenX = e.clientX - rect.left;
            const screenY = e.clientY - rect.top;
            
            const handle = getGlobalBaseMapTransformHandle(screenX, screenY);
            
            if (handle) {
                // Set cursor directly
                switch (handle) {
                    case 'nw':
                    case 'se':
                        canvas.style.cursor = 'nw-resize';
                        break;
                    case 'ne':
                    case 'sw':
                        canvas.style.cursor = 'ne-resize';
                        break;
                    case 'n':
                    case 's':
                        canvas.style.cursor = 'ns-resize';
                        break;
                    case 'w':
                    case 'e':
                        canvas.style.cursor = 'ew-resize';
                        break;
                    default:
                        canvas.style.cursor = 'move';
                }
            } else if (isPointInGlobalBaseMap(screenX, screenY)) {
                canvas.style.cursor = 'move';
            } else {
                canvas.style.cursor = 'default';
            }
        } else {
            canvas.style.cursor = 'default';
        }

        if (drawing && currentShape) {
            updateCurrentShape();
        } else if (isDragging) {
            updateDrag();
        }

        drawAll();
    }

    function handleMouseUp(e) {
        // Handle global base map transformation end
        if (isTransformingGlobalBaseMap) {
            isTransformingGlobalBaseMap = false;
            transformHandle = null;
            isDragging = false;
            return;
        }

        if (drawing && currentShape) {
            if (currentShape.type === 'polygon') {
                // For polygons, don't finish on mouse up - let user click to add points
            } else {
                finishCurrentShape();
            }
        } else if (isDragging) {
            finishDrag();
        }
    }

    function handleMouseWheel(e) {
        e.preventDefault();
        
        // Get mouse position relative to canvas
        const rect = canvas.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;
        
        // Use originalEvent to get the actual wheel event properties
        const originalEvent = e.originalEvent || e;
        
        // Debug: Log all available properties
        console.log('Wheel event properties:', {
            deltaY: originalEvent.deltaY,
            deltaX: originalEvent.deltaX,
            deltaZ: originalEvent.deltaZ,
            deltaMode: originalEvent.deltaMode,
            wheelDelta: originalEvent.wheelDelta,
            detail: originalEvent.detail,
            type: originalEvent.type
        });
        
        // Try to detect scroll direction using multiple methods
        let scrollUp = false;
        
        // Method 1: Check deltaY (modern browsers)
        if (originalEvent.deltaY !== undefined && originalEvent.deltaY !== 0) {
            scrollUp = originalEvent.deltaY < 0;
        }
        // Method 2: Check wheelDelta (older browsers)
        else if (originalEvent.wheelDelta !== undefined) {
            scrollUp = originalEvent.wheelDelta > 0;
        }
        // Method 3: Check detail (Firefox)
        else if (originalEvent.detail !== undefined) {
            scrollUp = originalEvent.detail < 0;
        }
        // Method 4: Check deltaX (horizontal scroll)
        else if (originalEvent.deltaX !== undefined && originalEvent.deltaX !== 0) {
            scrollUp = originalEvent.deltaX < 0;
        }
        // Method 5: Use a simple toggle for testing
        else {
            // If we can't detect direction, use a simple toggle
            scrollUp = Math.random() > 0.5; // This is just for testing
        }
        
        const zoomFactor = scrollUp ? 1.1 : 0.9;
        console.log('Scroll up:', scrollUp, 'Zoom factor:', zoomFactor);
        
        const oldScale = scale;
        
        // Calculate new scale with limits
        const newScale = Math.max(0.1, Math.min(5, scale * zoomFactor));
        
        if (newScale !== oldScale) {
            // Calculate zoom point in world coordinates
            const worldX = (mouseX - panX) / oldScale;
            const worldY = (mouseY - panY) / oldScale;
            
            // Update scale
            scale = newScale;
            
            // Adjust pan to zoom towards mouse cursor
            panX = mouseX - worldX * scale;
            panY = mouseY - worldY * scale;
            
            // Update zoom level display
            $('#zoom-level').text(Math.round(scale * 100) + '%');
            
            // Redraw
            drawAll();
        }
    }

    function handleDoubleClick(e) {
        if (drawing && currentShape && currentShape.type === 'polygon') {
            finishCurrentShape();
        }
    }

    // Drawing functions
    function startPolygon() {
        if (drawing) {
            return;
        }

        drawing = true;
        currentShape = {
            type: 'polygon',
            points: [{x: mouseX, y: mouseY}],
            status: 'available'
        };

        addToHistory();
    }

    function addPolygonPoint() {
        if (!currentShape || currentShape.type !== 'polygon') return;
        
        currentShape.points.push({x: mouseX, y: mouseY});
    }

    function startRectangle() {
        if (drawing) {
            return;
        }

        drawing = true;
        currentShape = {
            type: 'rectangle',
            startX: mouseX,
            startY: mouseY,
            endX: mouseX,
            endY: mouseY,
            status: 'available'
        };

        addToHistory();
    }

    function updateCurrentShape() {
        if (!currentShape) {
            return;
        }

        if (currentShape.type === 'polygon') {
            // For polygon, only update the last point to show preview
            // Don't add new points on mouse move - only on mouse clicks
            if (currentShape.points.length > 0) {
                currentShape.points[currentShape.points.length - 1] = {x: mouseX, y: mouseY};
            }
        } else if (currentShape.type === 'rectangle') {
            currentShape.endX = mouseX;
            currentShape.endY = mouseY;
        }
    }

    function finishCurrentShape() {
        if (!currentShape) return;

        if (currentShape.type === 'polygon') {
            if (currentShape.points.length >= 3) {
                // Close the polygon
                currentShape.points.push({x: startX, y: startY});

                // If we have a temporary plot (from createNewPlot), update it
                if (selectedPlot && !selectedPlot.id) {
                    selectedPlot.points = currentShape.points;
                    selectedPlot.type = 'polygon';
                } else {
                    // Otherwise, add as a new plot
                    plots.push(currentShape);
                }

                // Update form with plot coordinates
                $('#plot-coordinates').val(JSON.stringify(currentShape.points, null, 2));

                // Update the plot list
                updatePlotList();

                currentShape = null;
                drawing = false;
            }
        } else if (currentShape.type === 'rectangle') {
            const width = Math.abs(currentShape.endX - currentShape.startX);
            const height = Math.abs(currentShape.endY - currentShape.startY);

            if (width > 5 && height > 5) {
                // Convert rectangle to polygon points
                currentShape.points = [
                    {x: currentShape.startX, y: currentShape.startY},
                    {x: currentShape.endX, y: currentShape.startY},
                    {x: currentShape.endX, y: currentShape.endY},
                    {x: currentShape.startX, y: currentShape.endY}
                ];
                currentShape.type = 'polygon';

                // If we have a temporary plot (from createNewPlot), update it
                if (selectedPlot && !selectedPlot.id) {
                    selectedPlot.points = currentShape.points;
                    selectedPlot.type = 'polygon';
                } else {
                    // Otherwise, add as a new plot
                    plots.push(currentShape);
                }

                // Update form with plot coordinates
                $('#plot-coordinates').val(JSON.stringify(currentShape.points, null, 2));

                // Update the plot list
                updatePlotList();

                currentShape = null;
                drawing = false;
            }
        }

        drawAll();
    }

    function cancelDrawing() {
        drawing = false;
        currentShape = null;
        drawAll();
    }

    function selectShape() {
        // Find shape under cursor
        for (let i = plots.length - 1; i >= 0; i--) {
            const plot = plots[i];
            if (isPointInPolygon({x: mouseX, y: mouseY}, plot.points)) {
                selectedPlot = plot;
                break;
            }
        }

        if (selectedPlot) {
            loadPlotIntoForm(selectedPlot);
            
            // Update plot list selection
            $('.plot-list-item').removeClass('selected');
            if (selectedPlot.id) {
                $(`.plot-list-item[data-id="${selectedPlot.id}"]`).addClass('selected');
            }
        }
    }

    function editVertices() {
        if (!selectedPlot || !selectedPlot.points) return;

        // Find closest vertex
        let closestVertex = null;
        let closestDistance = Infinity;

        selectedPlot.points.forEach((point, index) => {
            const distance = Math.sqrt(Math.pow(point.x - mouseX, 2) + Math.pow(point.y - mouseY, 2));
            if (distance < 10 && distance < closestDistance) {
                closestDistance = distance;
                closestVertex = {point, index};
            }
        });

        if (closestVertex) {
            // Start dragging vertex
            isDragging = true;
            dragOffsetX = closestVertex.index; // Store the vertex index
            dragOffsetY = 0; // Not used for vertex editing
            startX = mouseX;
            startY = mouseY;
        }
    }

    function startMove() {
        if (!selectedPlot) return;

        isDragging = true;
        dragOffsetX = mouseX - selectedPlot.points[0].x;
        dragOffsetY = mouseY - selectedPlot.points[0].y;
    }

    function startRotate() {
        if (!selectedPlot || !selectedPlot.points) return;

        isDragging = true;
        startX = mouseX;
        startY = mouseY;
    }

    function duplicateSelectedPlot() {
        if (!selectedPlot) {
            alert('Please select a plot to duplicate.');
            return;
        }

        // Create a copy of the selected plot
        const duplicatedPlot = JSON.parse(JSON.stringify(selectedPlot));

        // Generate a new name
        const baseName = duplicatedPlot.plot_name || 'Plot';
        let counter = 1;
        let newName = `${baseName} Copy`;

        while (plots.some(p => p.plot_name === newName)) {
            counter++;
            newName = `${baseName} Copy ${counter}`;
        }

        duplicatedPlot.plot_name = newName;
        duplicatedPlot.id = null; // Mark as new plot

        // Offset the position slightly so it's visible
        if (duplicatedPlot.points) {
            duplicatedPlot.points.forEach(point => {
                point.x += 20;
                point.y += 20;
            });
        }

        // Add to plots array
        plots.push(duplicatedPlot);

        // Select the duplicated plot
        selectedPlot = duplicatedPlot;
        loadPlotIntoForm(duplicatedPlot);

        // Update the plot list
        updatePlotList();

        // Update coordinates field
        updateCoordinatesField();

        // Redraw canvas
        drawAll();

        $('#editor-status').text(`Created duplicate: ${newName}`);
    }

    function updateDrag() {
        if (!isDragging) return;

        if (currentTool === 'vertex' && selectedPlot && selectedPlot.points) {
            // Update vertex position
            const vertexIndex = dragOffsetX;
            if (selectedPlot.points[vertexIndex]) {
                selectedPlot.points[vertexIndex].x = mouseX;
                selectedPlot.points[vertexIndex].y = mouseY;
                
                // Update coordinates field in real-time
                updateCoordinatesField();
            }
        } else if (currentTool === 'move' && selectedPlot && selectedPlot.points) {
            // Move entire shape
            const deltaX = mouseX - startX;
            const deltaY = mouseY - startY;

            selectedPlot.points.forEach(point => {
                point.x += deltaX;
                point.y += deltaY;
            });

            startX = mouseX;
            startY = mouseY;
            
            // Update coordinates field in real-time
            updateCoordinatesField();
        } else if (currentTool === 'rotate' && selectedPlot && selectedPlot.points) {
            // Rotate shape around its center
            const centerX = selectedPlot.points.reduce((sum, p) => sum + p.x, 0) / selectedPlot.points.length;
            const centerY = selectedPlot.points.reduce((sum, p) => sum + p.y, 0) / selectedPlot.points.length;
            
            const angle = Math.atan2(mouseY - centerY, mouseX - centerX) - Math.atan2(startY - centerY, startX - centerX);
            
            selectedPlot.points.forEach(point => {
                const dx = point.x - centerX;
                const dy = point.y - centerY;
                const cos = Math.cos(angle);
                const sin = Math.sin(angle);
                
                point.x = centerX + dx * cos - dy * sin;
                point.y = centerY + dx * sin + dy * cos;
            });
            
            startX = mouseX;
            startY = mouseY;
            
            // Update coordinates field in real-time
            updateCoordinatesField();
        }
    }

    function finishDrag() {
        isDragging = false;
        if (selectedPlot) {
            addToHistory();
            // Update coordinates field when plot is modified
            updateCoordinatesField();
        }
    }

    // View controls
    function toggleFullscreen() {
        if (!document.fullscreenElement && !document.webkitFullscreenElement && !document.mozFullScreenElement && !document.msFullscreenElement) {
            // Enter fullscreen
            if (document.documentElement.requestFullscreen) {
                document.documentElement.requestFullscreen();
            } else if (document.documentElement.webkitRequestFullscreen) {
                document.documentElement.webkitRequestFullscreen();
            } else if (document.documentElement.mozRequestFullScreen) {
                document.documentElement.mozRequestFullScreen();
            } else if (document.documentElement.msRequestFullscreen) {
                document.documentElement.msRequestFullscreen();
            }
        } else {
            // Exit fullscreen
            if (document.exitFullscreen) {
                document.exitFullscreen();
            } else if (document.webkitExitFullscreen) {
                document.webkitExitFullscreen();
            } else if (document.mozCancelFullScreen) {
                document.mozCancelFullScreen();
            } else if (document.msExitFullscreen) {
                document.msExitFullscreen();
            }
        }
    }

    function zoom(factor) {
        scale *= factor;
        scale = Math.max(0.1, Math.min(5, scale));
        $('#zoom-level').text(Math.round(scale * 100) + '%');
        drawAll();
    }

    function fitToView() {
        if (plots.length === 0) {
            // If no plots, reset to default view
            scale = 1;
            panX = 0;
            panY = 0;
            $('#zoom-level').text(Math.round(scale * 100) + '%');
            drawAll();
            return;
        }

        let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;

        plots.forEach(plot => {
            if (plot.points) {
                plot.points.forEach(point => {
                    minX = Math.min(minX, point.x);
                    maxX = Math.max(maxX, point.x);
                    minY = Math.min(minY, point.y);
                    maxY = Math.max(maxY, point.y);
                });
            }
        });

        const padding = 50;
        const canvasWidth = canvas.width;
        const canvasHeight = canvas.height;

        const scaleX = (canvasWidth - padding * 2) / (maxX - minX);
        const scaleY = (canvasHeight - padding * 2) / (maxY - minY);
        scale = Math.min(scaleX, scaleY, 5); // Limit max zoom
        scale = Math.max(scale, 0.1); // Limit min zoom

        panX = (canvasWidth - (maxX + minX) * scale) / 2;
        panY = (canvasHeight - (maxY + minY) * scale) / 2;

        $('#zoom-level').text(Math.round(scale * 100) + '%');
        drawAll();
    }

    function toggleSnapToGrid() {
        snapToGrid = !snapToGrid;
        $('#snap-grid-toggle').toggleClass('active', snapToGrid);
    }

    function toggleShowGrid() {
        showGrid = !showGrid;
        $('#show-grid-toggle').toggleClass('active', showGrid);
        drawAll();
    }

    function undo() {
        if (historyIndex > 0) {
            historyIndex--;
            plots = JSON.parse(JSON.stringify(history[historyIndex]));
            drawAll();
        }
    }

    function clearAll() {
        if (confirm('Are you sure you want to clear all plots? This cannot be undone.')) {
            addToHistory();
            plots = [];
            selectedPlot = null;
            $('#plot-properties-form')[0].reset();
            drawAll();
        }
    }

    function addToHistory() {
        history = history.slice(0, historyIndex + 1);
        history.push(JSON.parse(JSON.stringify(plots)));
        historyIndex = history.length - 1;

        // Limit history size
        if (history.length > 50) {
            history = history.slice(-50);
            historyIndex = 49;
        }
    }

    // File upload functions
    function uploadBaseImage() {
        if (typeof wp === 'undefined' || !wp.media) {
            alert('WordPress media library not available');
            return;
        }

        const frame = wp.media({
            title: 'Select Base Map Image',
            button: { text: 'Use this image' },
            multiple: false,
            library: { type: 'image' }
        });

        frame.on('select', function() {
            const attachment = frame.state().get('selection').first().toJSON();
            $('#base-image-id').val(attachment.id);
            loadBaseImage(attachment.id);
        });

        frame.open();
    }

    function uploadPlotImage() {
        if (typeof wp === 'undefined' || !wp.media) {
            alert('WordPress media library not available');
            return;
        }

        const frame = wp.media({
            title: 'Select Plot Preview Image',
            button: { text: 'Use this image' },
            multiple: false,
            library: { type: 'image' }
        });

        frame.on('select', function() {
            const attachment = frame.state().get('selection').first().toJSON();
            $('#plot-image-id').val(attachment.id);
            $('#plot-image-preview').html(`<img src="${attachment.url}" alt="Plot preview" style="max-width: 100px; max-height: 100px;">`);
        });

        frame.open();
    }

    function loadBaseImage(imageId) {
        if (!imageId) {
            image = null;
            drawAll();
            return;
        }

        if (typeof wp === 'undefined' || !wp.media) {
            console.error('WordPress media library not available');
            return;
        }

        wp.media.attachment(imageId).fetch().then(function() {
            const url = wp.media.attachment(imageId).get('url');
            image = new Image();
            image.onload = function() {
                drawAll();
            };
            image.onerror = function() {
                console.error('Failed to load image:', url);
            };
            image.src = url;
            $('#base-image-preview').html(`<img src="${url}" alt="Base map" style="max-width: 100px; max-height: 100px;">`);
        }).catch(function(err) {
            console.error('Error loading image:', err);
        });
    }

    // Plot management
    function loadPlot(plotId) {
        let plot;

        // Handle both saved plots (with ID) and new plots (without ID)
        if (plotId) {
            plot = plots.find(p => p.id == plotId);
        } else {
            // For new plots, find the most recently created one
            plot = plots.find(p => !p.id);
        }

        if (!plot) return;

        selectedPlot = plot;
        loadPlotIntoForm(plot);

        // Visual feedback
        $('.plot-list-item').removeClass('selected');
        if (plotId) {
            $(`.plot-list-item[data-id="${plotId}"]`).addClass('selected');
        } else {
            // For new plots, highlight the first item or find by content
            $('.plot-list-item').first().addClass('selected');
        }
    }

    function loadPlotIntoForm(plot) {
        $('#plot-id').val(plot.id || '');
        $('#plot-name').val(plot.plot_name || '');
        $('#plot-sector').val(plot.sector || '');
        $('#plot-type').val(plot.type || '');
        $('#plot-category').val(plot.category || '');
        $('#plot-street').val(plot.street || '');
        $('#plot-description').val(plot.description || '');
        $('#plot-status').val(plot.status || 'available');
        $('#plot-price').val(plot.price || '');
        $('#plot-area').val(plot.area || '');

        // Update coordinates field with current plot points
        if (plot.points && plot.points.length > 0) {
            $('#plot-coordinates').val(JSON.stringify(plot.points, null, 2));
        } else {
            $('#plot-coordinates').val('');
        }

        if (plot.base_image_id && plot.base_image_id !== 0) {
            $('#base-image-id').val(plot.base_image_id);
            // Load base image by ID (this would need to be implemented to get image URL from ID)
            loadBaseImageById(plot.base_image_id);
        }

        // Load base image transform data
        if (plot.base_image_transform) {
            try {
                const transform = JSON.parse(plot.base_image_transform);
                baseImageTransform = { ...baseImageTransform, ...transform };
            } catch (e) {
                console.error('Error parsing base image transform:', e);
            }
        }

        // Update status message
        $('#editor-status').text(`Editing plot: ${plot.plot_name || 'Unnamed Plot'}`);
    }

    function savePlot(e) {
        e.preventDefault();

        const formData = $('#plot-properties-form').serializeArray();
        const plotData = {};

        formData.forEach(field => {
            plotData[field.name] = field.value;
        });
        
        console.log('Form data being saved:', plotData);
        console.log('Global base map image ID:', globalBaseMapImageId);
        console.log('Global base map transform:', globalBaseMapTransform);

        // Get coordinates
        try {
            plotData.coordinates = $('#plot-coordinates').val();
            if (!plotData.coordinates || plotData.coordinates.trim() === '') {
                alert('Please draw a plot shape first.');
                return;
            }
        } catch (e) {
            alert('Invalid coordinates format');
            return;
        }

        // Add global base map transform data (if in use)
        if (globalBaseMapImage && globalBaseMapImageId) {
            plotData.base_image_id = globalBaseMapImageId;
            plotData.base_image_transform = JSON.stringify(globalBaseMapTransform);
        }

        // Validate required fields
        if (!plotData.plot_name || plotData.plot_name.trim() === '') {
            alert('Please enter a plot name.');
            $('#plot-name').focus();
            return;
        }

        // Show loading overlays
        const $saveBtn = $('#save-plot');
        $saveBtn.addClass('loading');
        $saveBtn.find('.spinner').show();
        $('#global-loading-text').text('Saving plot...');
        $('#global-loading-overlay').css('display','flex');

        // Save via AJAX
        $.post(TajMapPB.ajaxUrl, {
            action: 'tajmap_pb_save_plot',
            nonce: TajMapPB.nonce,
            ...plotData
        }, function(response) {
            if (response.success) {
                alert('Plot saved successfully!');

                // Update local plot data
                if (response.data && response.data.id) {
                    // Update existing plot or add new plot
                    const existingIndex = plots.findIndex(p => p.id == response.data.id);
                    if (existingIndex >= 0) {
                        // Update existing plot
                        plots[existingIndex] = { ...plots[existingIndex], ...plotData, id: response.data.id };
                    } else {
                        // Add new plot
                        plots.push({ ...plotData, id: response.data.id });
                    }

                    // Update selected plot reference
                    if (selectedPlot) {
                        selectedPlot.id = response.data.id;
                    }

                    // Update form with new ID
                    $('#plot-id').val(response.data.id);

                    // Update plot list
                    updatePlotList();

                    // Redraw canvas
                    drawAll();
                }
            } else {
                alert('Error saving plot: ' + (response.data || 'Unknown error'));
            }
        }).fail(function() {
            alert('Network error. Please try again.');
        }).always(function() {
            // Hide loading overlays
            $saveBtn.removeClass('loading');
            $saveBtn.find('.spinner').hide();
            $('#global-loading-overlay').hide();
        });
    }

    function deletePlot(plotId) {
        // Handle unsaved plots (plotId is null)
        if (plotId === null || plotId === undefined || plotId === '') {
            if (confirm('Delete this unsaved plot?')) {
                // Remove from local plots array
                if (selectedPlot) {
                    const index = plots.indexOf(selectedPlot);
                    if (index > -1) {
                        plots.splice(index, 1);
                    }
                }
                selectedPlot = null;
                $('#plot-properties-form')[0].reset();
                $('#plot-coordinates').val('');
                $('.plot-list-item').removeClass('selected');
                updatePlotList();
                drawAll();
            }
            return;
        }

        // Handle saved plots (plotId is a valid ID)
        if (!confirm('Are you sure you want to delete this plot?')) return;

        // Show loading overlays
        const $deleteBtn = $('#delete-plot');
        $deleteBtn.addClass('loading');
        $deleteBtn.find('.spinner').show();
        $('#global-loading-text').text('Deleting plot...');
        $('#global-loading-overlay').css('display','flex');

        $.post(TajMapPB.ajaxUrl, {
            action: 'tajmap_pb_delete_plot',
            nonce: TajMapPB.nonce,
            id: plotId
        }, function(response) {
            if (response.success) {
                alert('Plot deleted successfully!');
                // Remove from local plots array
                plots = plots.filter(p => p.id != plotId);
                // Clear form if this was the selected plot
                if (selectedPlot && selectedPlot.id == plotId) {
                    selectedPlot = null;
                    $('#plot-properties-form')[0].reset();
                    $('#plot-coordinates').val('');
                    $('.plot-list-item').removeClass('selected');
                }
                // Update plot list
                updatePlotList();
                // Redraw canvas
                drawAll();
                // Reload plots from database to ensure consistency
                reloadPlotsFromDatabase();
            } else {
                alert('Error deleting plot: ' + (response.data || 'Unknown error'));
            }
        }).fail(function() {
            alert('Network error. Please try again.');
        }).always(function() {
            // Hide loading overlays
            $deleteBtn.removeClass('loading');
            $deleteBtn.find('.spinner').hide();
            $('#global-loading-overlay').hide();
        });
    }

    function updateCoordinatesField() {
        if (selectedPlot && selectedPlot.points) {
            $('#plot-coordinates').val(JSON.stringify(selectedPlot.points, null, 2));
        }
    }
    // (removed) plot details helpers

    function updatePlotList() {
        // Update the plot count in the sidebar header
        $('#plots-total-count').text(plots.length);

        // If no plots exist, show the create first plot message
        if (plots.length === 0) {
            $('#plots-list').html(`
                <div class="no-plots">
                    <p>No plots created yet.</p>
                    <button class="btn primary" onclick="createNewPlot()">Create First Plot</button>
                </div>
            `);
            return;
        }

        // Generate plot list HTML
        let plotListHtml = '';
        plots.forEach(plot => {
            const statusClass = plot.status || 'available';
            plotListHtml += `
                <div class="plot-list-item" data-id="${plot.id || ''}"
                     data-name="${(plot.plot_name || 'Unnamed Plot').toLowerCase()}"
                     data-sector="${(plot.sector || '').toLowerCase()}"
                     data-type="${(plot.type || '').toLowerCase()}"
                     data-category="${(plot.category || '').toLowerCase()}"
                     data-street="${(plot.street || '').toLowerCase()}"
                     data-status="${statusClass.toLowerCase()}">
                    <div class="plot-info">
                        <h4>${plot.plot_name || 'Unnamed Plot'}</h4>
                        <div class="plot-meta">
                            <span class="plot-status ${statusClass}">
                                ${statusClass.charAt(0).toUpperCase() + statusClass.slice(1)}
                            </span>
                            ${plot.sector ? `<span class="plot-sector">${plot.sector}</span>` : ''}
                            ${plot.type ? `<span class="plot-type">${plot.type}</span>` : ''}
                        </div>
                    </div>
                    <div class="plot-actions">
                        <button class="btn-icon edit" title="Edit Plot">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                        </button>
                        <button class="btn-icon delete" title="Delete Plot">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="3,6 5,6 21,6"></polyline>
                                <path d="M19,6v14a2,2 0 0,1-2,2H7a2,2 0 0,1-2-2V6m3,0V4a2,2 0 0,1,2-2h4a2,2 0 0,1,2,2v2"></path>
                            </svg>
                        </button>
                    </div>
                </div>
            `;
        });

        $('#plots-list').html(plotListHtml);
    }

    function filterPlots(searchQuery) {
        const plotItems = $('.plot-list-item');
        let visibleCount = 0;

        if (!searchQuery || searchQuery.trim() === '') {
            // Show all plots if search is empty
            plotItems.show();
            visibleCount = plotItems.length;
        } else {
            // Filter plots based on search query
            plotItems.each(function() {
                const $item = $(this);
                const name = $item.data('name') || '';
                const sector = $item.data('sector') || '';
                const type = $item.data('type') || '';
                const category = $item.data('category') || '';
                const street = $item.data('street') || '';
                const status = $item.data('status') || '';

                // Check if any field matches the search query
                const matches = name.includes(searchQuery) ||
                              sector.includes(searchQuery) ||
                              type.includes(searchQuery) ||
                              category.includes(searchQuery) ||
                              street.includes(searchQuery) ||
                              status.includes(searchQuery);

                if (matches) {
                    $item.show();
                    visibleCount++;
                } else {
                    $item.hide();
                }
            });
        }

        // Update the count to show filtered results
        $('#plots-total-count').text(visibleCount);

        // Show message if no results
        if (visibleCount === 0) {
            if ($('#no-search-results').length === 0) {
                $('#plots-list').append(`
                    <div id="no-search-results" class="no-plots">
                        <p>No plots found matching "${searchQuery}"</p>
                    </div>
                `);
            }
        } else {
            $('#no-search-results').remove();
        }
    }

    function sortPlots(sortBy) {
        console.log('🔄 Sorting plots by:', sortBy);
        console.log('📊 Current plots:', plots);
        
        if (!plots || plots.length === 0) {
            console.log('⚠️ No plots to sort');
            return;
        }
        
        let sortedPlots = [...plots]; // Create a copy to avoid mutating original
        
        switch (sortBy) {
            case 'newest':
                console.log('📅 Sorting by newest (created_at)');
                sortedPlots.sort((a, b) => {
                    // Use created_at if available, otherwise fall back to id (higher id = newer)
                    const dateA = a.created_at ? new Date(a.created_at) : new Date(0);
                    const dateB = b.created_at ? new Date(b.created_at) : new Date(0);
                    
                    // If both have created_at, use that. Otherwise use id as fallback
                    if (a.created_at && b.created_at) {
                        return dateB - dateA;
                    } else {
                        return (b.id || 0) - (a.id || 0);
                    }
                });
                break;
            case 'oldest':
                console.log('📅 Sorting by oldest (created_at)');
                sortedPlots.sort((a, b) => {
                    // Use created_at if available, otherwise fall back to id (lower id = older)
                    const dateA = a.created_at ? new Date(a.created_at) : new Date(0);
                    const dateB = b.created_at ? new Date(b.created_at) : new Date(0);
                    
                    // If both have created_at, use that. Otherwise use id as fallback
                    if (a.created_at && b.created_at) {
                        return dateA - dateB;
                    } else {
                        return (a.id || 0) - (b.id || 0);
                    }
                });
                break;
            case 'name-asc':
                console.log('🔤 Sorting by name A-Z');
                sortedPlots.sort((a, b) => (a.plot_name || '').localeCompare(b.plot_name || ''));
                break;
            case 'name-desc':
                console.log('🔤 Sorting by name Z-A');
                sortedPlots.sort((a, b) => (b.plot_name || '').localeCompare(a.plot_name || ''));
                break;
            case 'status':
                console.log('📊 Sorting by status');
                sortedPlots.sort((a, b) => (a.status || '').localeCompare(b.status || ''));
                break;
            case 'sector':
                console.log('🏢 Sorting by sector');
                sortedPlots.sort((a, b) => (a.sector || '').localeCompare(b.sector || ''));
                break;
            default:
                console.log('❌ Unknown sort option:', sortBy);
                return; // No sorting needed
        }
        
        console.log('✅ Sorted plots:', sortedPlots);
        
        // Update the plots array
        plots = sortedPlots;
        
        console.log('🔄 Updated plots array:', plots);
        
        // Re-render the plot list
        updatePlotList();
        
        // Re-draw the canvas
        drawAll();
        
        console.log('🔄 Sorting completed');
        
        // Test: Log the first few plot names to verify sorting worked
        console.log('📋 First 3 plots after sorting:', plots.slice(0, 3).map(p => p.plot_name));
    }
    
    // Test function - can be called from console
    window.testSorting = function() {
        console.log('🧪 Testing sorting functionality...');
        console.log('📊 Current plots:', plots);
        if (plots.length > 0) {
            console.log('📊 First plot:', plots[0]);
            sortPlots('name-asc');
        } else {
            console.log('❌ No plots to test with');
        }
    };

    // Drawing functions
    function drawAll() {
        if (!ctx || !canvas) {
            return;
        }

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Apply transformations for base map, plots and grid (unified coordinate system)
        ctx.save();
        ctx.translate(panX, panY);
        ctx.scale(scale, scale);

        // Draw global base map image first (background layer) - now in world coordinates
        if (globalBaseMapImage) {
            try {
                // Draw the global base map image as background in world coordinates
                ctx.drawImage(
                    globalBaseMapImage,
                    globalBaseMapTransform.x,
                    globalBaseMapTransform.y,
                    globalBaseMapTransform.width,
                    globalBaseMapTransform.height
                );
                
                // Draw transform handles if in transform mode (in world coordinates)
                if (isTransformingGlobalBaseMap) {
                    drawGlobalBaseMapHandles();
                }
            } catch (e) {
                console.error('Error drawing global base map image:', e);
            }
        }

        // Draw grid
        if (showGrid) {
            drawGrid();
        }

        // Draw plots
        plots.forEach(plot => {
            drawPlot(plot);
        });

        // Draw current shape being created
        if (currentShape) {
            drawPlot(currentShape);
        }

        // Draw selection highlight
        if (selectedPlot) {
            ctx.strokeStyle = '#3b82f6';
            ctx.lineWidth = 3 / scale;
            ctx.setLineDash([5 / scale, 5 / scale]);
            if (selectedPlot.points) {
                drawPolygon(selectedPlot.points);
            }
            ctx.setLineDash([]);
        }

        ctx.restore();
    }

    function drawGrid() {
        ctx.strokeStyle = 'rgba(59, 130, 246, 0.2)';
        ctx.lineWidth = 1 / scale;

        const startX = Math.floor(-panX / scale / gridSize) * gridSize;
        const startY = Math.floor(-panY / scale / gridSize) * gridSize;
        const endX = startX + (canvas.width / scale) + gridSize;
        const endY = startY + (canvas.height / scale) + gridSize;

        for (let x = startX; x <= endX; x += gridSize) {
            ctx.beginPath();
            ctx.moveTo(x, startY);
            ctx.lineTo(x, endY);
            ctx.stroke();
        }

        for (let y = startY; y <= endY; y += gridSize) {
            ctx.beginPath();
            ctx.moveTo(startX, y);
            ctx.lineTo(endX, y);
            ctx.stroke();
        }
    }

    function drawPlot(plot) {
        ctx.save();

        // Fill color based on status
        switch (plot.status) {
            case 'sold':
                ctx.fillStyle = 'rgba(239, 68, 68, 0.3)';
                ctx.strokeStyle = '#dc2626';
                break;
            case 'reserved':
                ctx.fillStyle = 'rgba(245, 158, 11, 0.7)'; // Yellow for reserved
                ctx.strokeStyle = '#d97706';
                break;
            case 'available':
            default:
                ctx.fillStyle = 'rgba(16, 185, 129, 0.3)';
                ctx.strokeStyle = '#059669';
                break;
        }

        ctx.lineWidth = 2 / scale;

        // Handle different shape types
        if (plot.type === 'rectangle') {
            drawRectangle(plot);
        } else if (plot.points && plot.points.length >= 1) {
            // For polygons, draw even with 1 point (during drawing)
            drawPolygon(plot.points);
        } else {
            // Not enough points to draw anything
            ctx.restore();
            return;
        }

        // Draw vertices if selected or hovered
        if (selectedPlot === plot || plot === currentShape) {
            if (plot.points) {
                plot.points.forEach((point, index) => {
                    // Different colors for different states
                    if (currentTool === 'vertex') {
                        ctx.fillStyle = '#ef4444'; // Red for vertex editing mode
                        ctx.strokeStyle = '#ffffff';
                        ctx.lineWidth = 2 / scale;
                    } else {
                        ctx.fillStyle = '#3b82f6'; // Blue for normal selection
                        ctx.strokeStyle = '#ffffff';
                        ctx.lineWidth = 1 / scale;
                    }
                    
                    ctx.beginPath();
                    ctx.arc(point.x, point.y, 6 / scale, 0, 2 * Math.PI);
                    ctx.fill();
                    ctx.stroke();
                });
            }
        }

        ctx.restore();
    }

    function drawRectangle(plot) {
        if (!plot.startX || !plot.startY || !plot.endX || !plot.endY) {
            return;
        }

        const x = Math.min(plot.startX, plot.endX);
        const y = Math.min(plot.startY, plot.endY);
        const width = Math.abs(plot.endX - plot.startX);
        const height = Math.abs(plot.endY - plot.startY);

        ctx.beginPath();
        ctx.rect(x, y, width, height);
        ctx.fill();
        ctx.stroke();
    }

    function drawPolygon(points) {
        if (!points || points.length < 1) {
            return;
        }

        if (points.length === 1) {
            // Draw a dot for single point
            ctx.beginPath();
            ctx.arc(points[0].x, points[0].y, 3, 0, 2 * Math.PI);
            ctx.fill();
        } else {
            // Draw polygon with multiple points
            ctx.beginPath();
            ctx.moveTo(points[0].x, points[0].y);

            for (let i = 1; i < points.length; i++) {
                ctx.lineTo(points[i].x, points[i].y);
            }

            // Only close path if we have 3 or more points (complete polygon)
            if (points.length >= 3) {
                ctx.closePath();
            }

            ctx.fill();
            ctx.stroke();
        }
    }

    // Utility functions
    function isPointInPolygon(point, polygon) {
        if (!polygon || polygon.length < 3) return false;

        let inside = false;

        for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
            if (((polygon[i].y > point.y) !== (polygon[j].y > point.y)) &&
                (point.x < (polygon[j].x - polygon[i].x) * (point.y - polygon[i].y) / (polygon[j].y - polygon[i].y) + polygon[i].x)) {
                inside = !inside;
            }
        }

        return inside;
    }

    // Handle fullscreen change
    $(document).on('fullscreenchange webkitfullscreenchange mozfullscreenchange MSFullscreenChange', function() {
        const isFullscreen = !!(document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement);
        $('#fullscreen-toggle').toggleClass('active', isFullscreen);

        if (isFullscreen) {
            $('.tajmap-plot-editor').addClass('fullscreen');
        } else {
            $('.tajmap-plot-editor').removeClass('fullscreen');
        }
    });

    // Create new plot function
    function createNewPlot() {
        // Clear form
        $('#plot-properties-form')[0].reset();

        // Clear plot ID (indicates new plot)
        $('#plot-id').val('');

        // Clear coordinates
        $('#plot-coordinates').val('');

        // Clear selected plot
        selectedPlot = null;

        // Remove selection highlighting
        $('.plot-list-item').removeClass('selected');
        
        // (removed) hide details panel

        // Switch to polygon tool
        selectTool('polygon');

        // Update status
        $('#editor-status').text('Ready to create new plot - Draw a polygon');

        // Show instructions
        if (!$('#new-plot-instructions').length) {
            $('.editor-canvas-wrapper').prepend(`
                <div id="new-plot-instructions" style="
                    position: absolute;
                    top: 20px;
                    left: 50%;
                    transform: translateX(-50%);
                    background: rgba(0, 0, 0, 0.8);
                    color: white;
                    padding: 10px 20px;
                    border-radius: 5px;
                    font-size: 14px;
                    z-index: 1000;
                    pointer-events: none;
                ">
                    Click on the canvas to start drawing a polygon. Double-click to finish.
                </div>
            `);

            // Auto-hide instructions after 5 seconds
            setTimeout(() => {
                $('#new-plot-instructions').fadeOut();
            }, 5000);
        } else {
            $('#new-plot-instructions').show();
        }

        // Create a temporary placeholder for the new plot in the list
        const tempPlot = {
            id: null,
            plot_name: 'New Plot',
            status: 'available',
            points: []
        };

        // Add to plots array temporarily
        plots.push(tempPlot);
        selectedPlot = tempPlot;

        // Update plot list to show the new plot placeholder
        updatePlotList();
    }

    // Global base map image upload function
    function uploadBaseImage() {
        console.log('uploadGlobalBaseMapImage called');
        
        if (typeof wp === 'undefined' || typeof wp.media === 'undefined') {
            console.error('WordPress media uploader not available');
            alert('WordPress media uploader not available. Please refresh the page.');
            return;
        }
        
        console.log('Creating media uploader for global base map');
        const mediaUploader = wp.media({
            title: 'Select Base Map Image (Canvas Background)',
            button: {
                text: 'Use as Base Map'
            },
            multiple: false,
            library: {
                type: 'image'
            }
        });

        mediaUploader.on('select', function() {
            console.log('Base map image selected from media uploader');
            const attachment = mediaUploader.state().get('selection').first().toJSON();
            console.log('Selected base map attachment:', attachment);
            loadGlobalBaseMapImage(attachment.url, attachment.id);
            // Auto-save the global base map setting
            saveGlobalBaseMapSetting(attachment.id);
        });

        console.log('Opening media uploader for base map');
        mediaUploader.open();
    }

    function uploadPlotImage() {
        const mediaUploader = wp.media({
            title: 'Select Plot Preview Image',
            button: {
                text: 'Use this image'
            },
            multiple: false,
            library: {
                type: 'image'
            }
        });

        mediaUploader.on('select', function() {
            const attachment = mediaUploader.state().get('selection').first().toJSON();
            $('#plot-image-id').val(attachment.id);
            $('#plot-image-preview').html(`
                <img src="${attachment.url}" style="max-width: 100px; max-height: 100px; border-radius: 4px;">
                <button type="button" class="remove-image" onclick="removePlotImage()">×</button>
            `);
        });

        mediaUploader.open();
    }

    function loadGlobalBaseMapImage(imageUrl = null, imageId = null) {
        // If no parameters provided, load from saved setting
        if (!imageUrl && !imageId) {
            loadGlobalBaseMapFromSetting();
            return;
        }
        
        globalBaseMapImage = new Image();
        globalBaseMapImage.onload = function() {
            // Calculate initial transform to fit image in canvas
            const canvasWidth = canvas.width;
            const canvasHeight = canvas.height;
            const imageAspect = globalBaseMapImage.width / globalBaseMapImage.height;
            const canvasAspect = canvasWidth / canvasHeight;
            
            if (imageAspect > canvasAspect) {
                // Image is wider than canvas
                globalBaseMapTransform.scale = canvasWidth / globalBaseMapImage.width;
                globalBaseMapTransform.width = canvasWidth;
                globalBaseMapTransform.height = globalBaseMapImage.height * globalBaseMapTransform.scale;
            } else {
                // Image is taller than canvas
                globalBaseMapTransform.scale = canvasHeight / globalBaseMapImage.height;
                globalBaseMapTransform.width = globalBaseMapImage.width * globalBaseMapTransform.scale;
                globalBaseMapTransform.height = canvasHeight;
            }
            
            // Center the image
            globalBaseMapTransform.x = (canvasWidth - globalBaseMapTransform.width) / 2;
            globalBaseMapTransform.y = (canvasHeight - globalBaseMapTransform.height) / 2;
            
            // Store image ID
            globalBaseMapImageId = imageId;
            console.log('Global base map loaded and ID set to:', imageId);
            
            // Update preview
            $('#base-image-preview').html(`
                <img src="${imageUrl}" style="max-width: 100px; max-height: 100px; border-radius: 4px;">
                <button type="button" class="remove-image" onclick="removeGlobalBaseMap()">×</button>
                <div style="font-size: 11px; color: #666; margin-top: 4px;">Canvas Background</div>
            `);
            
            // Show transform button
            $('#transform-base-image').show().text('Transform Base Map');
            
            // Redraw canvas
            drawAll();
        };
        globalBaseMapImage.onerror = function() {
            console.error('Failed to load global base map image:', imageUrl);
        };
        globalBaseMapImage.src = imageUrl;
    }

    function removeBaseImage() {
        baseImage = null;
        baseImageTransform = {
            x: 0,
            y: 0,
            scale: 1,
            rotation: 0,
            width: 0,
            height: 0
        };
        isTransformingBaseImage = false;
        transformHandle = null;
        $('#base-image-id').val('');
        $('#base-image-preview').empty();
        $('#transform-base-image').hide();
        drawAll();
    }

    function toggleBaseImageTransform() {
        if (!globalBaseMapImage) return;
        
        isTransformingGlobalBaseMap = !isTransformingGlobalBaseMap;
        const button = $('#transform-base-image');
        
        if (isTransformingGlobalBaseMap) {
            button.text('Exit Transform').addClass('active');
            button.css('background', '#ef4444');
        } else {
            button.text('Transform Base Map').removeClass('active');
            button.css('background', '');
            transformHandle = null;
            // Reset cursor
            if (canvas) {
                canvas.style.cursor = 'default';
            }
        }
        
        drawAll();
    }

    function removePlotImage() {
        $('#plot-image-id').val('');
        $('#plot-image-preview').empty();
    }

    function loadBaseImageById(imageId) {
        console.log('loadBaseImageById called with ID:', imageId);
        // Get image URL from WordPress media library
        $.post(TajMapPB.ajaxUrl, {
            action: 'tajmap_pb_get_image_url',
            nonce: TajMapPB.nonce,
            image_id: imageId
        }, function(response) {
            console.log('AJAX response for image URL:', response);
            if (response.success && response.data.url) {
                console.log('Loading base image from URL:', response.data.url);
                loadBaseImage(response.data.url, imageId);
            } else {
                console.error('Failed to load image URL for ID:', imageId, response);
            }
        }).fail(function(xhr, status, error) {
            console.error('AJAX failed to get image URL:', status, error);
        });
    }

    // Global base map transformation functions
    function isPointInGlobalBaseMap(x, y) {
        if (!globalBaseMapImage) return false;
        
        // Convert mouse coordinates to world coordinates
        const worldX = (x - panX) / scale;
        const worldY = (y - panY) / scale;
        
        return worldX >= globalBaseMapTransform.x && 
               worldX <= globalBaseMapTransform.x + globalBaseMapTransform.width &&
               worldY >= globalBaseMapTransform.y && 
               worldY <= globalBaseMapTransform.y + globalBaseMapTransform.height;
    }

    function getGlobalBaseMapTransformHandle(x, y) {
        if (!globalBaseMapImage) return null;
        
        const handleSize = 8 / scale; // Scale handle size with zoom
        // Convert mouse coordinates to world coordinates
        const worldX = (x - panX) / scale;
        const worldY = (y - panY) / scale;
        
        const handles = [
            { name: 'nw', x: globalBaseMapTransform.x, y: globalBaseMapTransform.y },
            { name: 'ne', x: globalBaseMapTransform.x + globalBaseMapTransform.width, y: globalBaseMapTransform.y },
            { name: 'sw', x: globalBaseMapTransform.x, y: globalBaseMapTransform.y + globalBaseMapTransform.height },
            { name: 'se', x: globalBaseMapTransform.x + globalBaseMapTransform.width, y: globalBaseMapTransform.y + globalBaseMapTransform.height },
            { name: 'n', x: globalBaseMapTransform.x + globalBaseMapTransform.width / 2, y: globalBaseMapTransform.y },
            { name: 's', x: globalBaseMapTransform.x + globalBaseMapTransform.width / 2, y: globalBaseMapTransform.y + globalBaseMapTransform.height },
            { name: 'w', x: globalBaseMapTransform.x, y: globalBaseMapTransform.y + globalBaseMapTransform.height / 2 },
            { name: 'e', x: globalBaseMapTransform.x + globalBaseMapTransform.width, y: globalBaseMapTransform.y + globalBaseMapTransform.height / 2 }
        ];
        
        for (let handle of handles) {
            if (Math.abs(worldX - handle.x) <= handleSize && Math.abs(worldY - handle.y) <= handleSize) {
                return handle.name;
            }
        }
        
        return null;
    }

    function transformGlobalBaseMap(handle, deltaX, deltaY) {
        if (!globalBaseMapImage) return;
        
        // Convert screen delta to world delta
        const worldDeltaX = deltaX / scale;
        const worldDeltaY = deltaY / scale;
        
        switch (handle) {
            case 'nw':
                globalBaseMapTransform.x += worldDeltaX;
                globalBaseMapTransform.y += worldDeltaY;
                globalBaseMapTransform.width -= worldDeltaX;
                globalBaseMapTransform.height -= worldDeltaY;
                break;
            case 'ne':
                globalBaseMapTransform.y += worldDeltaY;
                globalBaseMapTransform.width += worldDeltaX;
                globalBaseMapTransform.height -= worldDeltaY;
                break;
            case 'sw':
                globalBaseMapTransform.x += worldDeltaX;
                globalBaseMapTransform.width -= worldDeltaX;
                globalBaseMapTransform.height += worldDeltaY;
                break;
            case 'se':
                globalBaseMapTransform.width += worldDeltaX;
                globalBaseMapTransform.height += worldDeltaY;
                break;
            case 'n':
                globalBaseMapTransform.y += worldDeltaY;
                globalBaseMapTransform.height -= worldDeltaY;
                break;
            case 's':
                globalBaseMapTransform.height += worldDeltaY;
                break;
            case 'w':
                globalBaseMapTransform.x += worldDeltaX;
                globalBaseMapTransform.width -= worldDeltaX;
                break;
            case 'e':
                globalBaseMapTransform.width += worldDeltaX;
                break;
            case 'move':
                globalBaseMapTransform.x += worldDeltaX;
                globalBaseMapTransform.y += worldDeltaY;
                break;
        }
        
        // Ensure minimum size
        globalBaseMapTransform.width = Math.max(50, globalBaseMapTransform.width);
        globalBaseMapTransform.height = Math.max(50, globalBaseMapTransform.height);
        
        // Auto-save the transform
        saveGlobalBaseMapSetting(globalBaseMapImageId);
        drawAll();
    }

    function drawGlobalBaseMapHandles() {
        if (!globalBaseMapImage) return;
        
        const handleSize = 8;
        const handles = [
            { name: 'nw', x: globalBaseMapTransform.x, y: globalBaseMapTransform.y },
            { name: 'ne', x: globalBaseMapTransform.x + globalBaseMapTransform.width, y: globalBaseMapTransform.y },
            { name: 'sw', x: globalBaseMapTransform.x, y: globalBaseMapTransform.y + globalBaseMapTransform.height },
            { name: 'se', x: globalBaseMapTransform.x + globalBaseMapTransform.width, y: globalBaseMapTransform.y + globalBaseMapTransform.height },
            { name: 'n', x: globalBaseMapTransform.x + globalBaseMapTransform.width / 2, y: globalBaseMapTransform.y },
            { name: 's', x: globalBaseMapTransform.x + globalBaseMapTransform.width / 2, y: globalBaseMapTransform.y + globalBaseMapTransform.height },
            { name: 'w', x: globalBaseMapTransform.x, y: globalBaseMapTransform.y + globalBaseMapTransform.height / 2 },
            { name: 'e', x: globalBaseMapTransform.x + globalBaseMapTransform.width, y: globalBaseMapTransform.y + globalBaseMapTransform.height / 2 }
        ];
        
        // Draw border (in world coordinates)
        ctx.strokeStyle = '#3b82f6';
        ctx.lineWidth = 2 / scale; // Scale line width with zoom
        ctx.strokeRect(
            globalBaseMapTransform.x,
            globalBaseMapTransform.y,
            globalBaseMapTransform.width,
            globalBaseMapTransform.height
        );
        
        // Draw handles (in world coordinates)
        ctx.fillStyle = '#3b82f6';
        handles.forEach(handle => {
            ctx.fillRect(
                handle.x - handleSize / 2,
                handle.y - handleSize / 2,
                handleSize,
                handleSize
            );
        });
    }

    // Global base map management functions
    function saveGlobalBaseMapSetting(imageId) {
        console.log('Saving global base map setting:', imageId);
        $.post(TajMapPB.ajaxUrl, {
            action: 'tajmap_pb_save_global_base_map',
            nonce: TajMapPB.nonce,
            base_map_image_id: imageId,
            base_map_transform: JSON.stringify(globalBaseMapTransform)
        }, function(response) {
            if (response.success) {
                console.log('Global base map setting saved successfully');
            } else {
                console.error('Failed to save global base map setting:', response);
            }
        }).fail(function(xhr, status, error) {
            console.error('AJAX failed to save global base map setting:', status, error);
        });
    }
    
    function loadGlobalBaseMapFromSetting() {
        console.log('Loading global base map from settings');
        $.post(TajMapPB.ajaxUrl, {
            action: 'tajmap_pb_get_global_base_map',
            nonce: TajMapPB.nonce
        }, function(response) {
            if (response.success && response.data.base_map_image_id) {
                console.log('Found saved global base map:', response.data.base_map_image_id);
                // Get image URL and load it
                $.post(TajMapPB.ajaxUrl, {
                    action: 'tajmap_pb_get_image_url',
                    nonce: TajMapPB.nonce,
                    image_id: response.data.base_map_image_id
                }, function(imageResponse) {
                    if (imageResponse.success && imageResponse.data.url) {
                        loadGlobalBaseMapImage(imageResponse.data.url, response.data.base_map_image_id);
                        // Load saved transform if available
                        if (response.data.base_map_transform) {
                            try {
                                globalBaseMapTransform = JSON.parse(response.data.base_map_transform);
                                drawAll(); // Redraw with saved transform
                            } catch (e) {
                                console.error('Error parsing saved base map transform:', e);
                            }
                        }
                    }
                });
            } else {
                console.log('No global base map setting found');
            }
        }).fail(function(xhr, status, error) {
            console.error('AJAX failed to load global base map setting:', status, error);
        });
    }
    
    function removeGlobalBaseMap() {
        globalBaseMapImage = null;
        globalBaseMapImageId = null;
        globalBaseMapTransform = {
            x: 0,
            y: 0,
            scale: 1,
            rotation: 0,
            width: 0,
            height: 0
        };
        isTransformingGlobalBaseMap = false;
        transformHandle = null;
        $('#base-image-preview').empty();
        $('#transform-base-image').hide();
        
        // Save the removal
        saveGlobalBaseMapSetting(null);
        
        drawAll();
    }

    // Function to reload plots from database
    function reloadPlotsFromDatabase() {
        console.log('🔄 Reloading plots from database...');
        $.post(TajMapPB.ajaxUrl, {
            action: 'tajmap_pb_get_plots',
            nonce: TajMapPB.nonce
        }, function(response) {
            if (response.success && response.data && response.data.plots) {
                console.log('🔄 Loaded plots from database:', response.data.plots);
                plots = response.data.plots;
                
                // Parse coordinates for each plot
                plots.forEach(plot => {
                    if (typeof plot.coordinates === 'string') {
                        try {
                            plot.points = JSON.parse(plot.coordinates);
                        } catch (e) {
                            console.error('Error parsing coordinates for plot:', plot.id);
                            plot.points = [];
                        }
                    }
                });
                
                // Update plot list and redraw
                updatePlotList();
                drawAll();
                console.log('🔄 Plots reloaded successfully');
            } else {
                console.error('🔄 Failed to reload plots:', response);
            }
        }).fail(function(xhr, status, error) {
            console.error('🔄 AJAX failed to reload plots:', status, error);
        });
    }

    // Make functions globally available
    window.initializePlotEditor = initializePlotEditor;
    window.createNewPlot = createNewPlot;
    window.removeGlobalBaseMap = removeGlobalBaseMap;
    window.removePlotImage = removePlotImage;

})(jQuery);
