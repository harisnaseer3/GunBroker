<?php
/**
 * Plugin Name: TajMap Plot Booking
 * Description: Interactive real estate plot booking system with SVG overlays, admin polygon editor, and lead capture.
 * Version: 2.0.4
 * Author: TajMap
 * License: GPL2
 */

if (!defined('ABSPATH')) {
	exit;
}

// Constants
if (!defined('TAJMAP_PB_VERSION')) {
	define('TAJMAP_PB_VERSION', '2.0.4');
}
if (!defined('TAJMAP_PB_PATH')) {
	define('TAJMAP_PB_PATH', plugin_dir_path(__FILE__));
}
if (!defined('TAJMAP_PB_URL')) {
	define('TAJMAP_PB_URL', plugin_dir_url(__FILE__));
}
if (!defined('TAJMAP_PB_TABLE_PLOTS')) {
	global $wpdb;
	define('TAJMAP_PB_TABLE_PLOTS', $wpdb->prefix . 'tajmap_plots');
}
if (!defined('TAJMAP_PB_TABLE_LEADS')) {
	global $wpdb;
	define('TAJMAP_PB_TABLE_LEADS', $wpdb->prefix . 'tajmap_leads');
}
if (!defined('TAJMAP_PB_TABLE_USERS')) {
	global $wpdb;
	define('TAJMAP_PB_TABLE_USERS', $wpdb->prefix . 'tajmap_users');
}
if (!defined('TAJMAP_PB_TABLE_SAVED_PLOTS')) {
	global $wpdb;
	define('TAJMAP_PB_TABLE_SAVED_PLOTS', $wpdb->prefix . 'tajmap_saved_plots');
}
if (!defined('TAJMAP_PB_TABLE_LEAD_HISTORY')) {
	global $wpdb;
	define('TAJMAP_PB_TABLE_LEAD_HISTORY', $wpdb->prefix . 'tajmap_lead_history');
}

register_activation_hook(__FILE__, function () {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$charset_collate = $wpdb->get_charset_collate();

	$plots_sql = "CREATE TABLE IF NOT EXISTS `" . TAJMAP_PB_TABLE_PLOTS . "` (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		plot_name VARCHAR(191) NOT NULL,
		street VARCHAR(191) NULL,
		sector VARCHAR(191) NULL,
		type VARCHAR(191) NULL,
		category VARCHAR(191) NULL,
		coordinates LONGTEXT NOT NULL,
		status ENUM('available','reserved','sold') NOT NULL DEFAULT 'available',
		base_image_id BIGINT UNSIGNED NULL,
		base_image_transform LONGTEXT NULL,
		created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
		updated_at DATETIME NULL DEFAULT NULL,
		PRIMARY KEY (id),
		KEY status_idx (status)
	) $charset_collate;";
	dbDelta($plots_sql);
	
	// Update status ENUM to include 'reserved' for existing tables
	$wpdb->query("ALTER TABLE `" . TAJMAP_PB_TABLE_PLOTS . "` MODIFY COLUMN `status` ENUM('available','reserved','sold') NOT NULL DEFAULT 'available'");
	
	// Add admin_user_id column to leads table if it doesn't exist
	$admin_user_column = $wpdb->get_results($wpdb->prepare(
		"SHOW COLUMNS FROM `" . TAJMAP_PB_TABLE_LEADS . "` LIKE %s",
		'admin_user_id'
	));
	if (empty($admin_user_column)) {
		$wpdb->query("ALTER TABLE `" . TAJMAP_PB_TABLE_LEADS . "` ADD COLUMN `admin_user_id` BIGINT UNSIGNED NULL AFTER `plot_id`");
		$wpdb->query("ALTER TABLE `" . TAJMAP_PB_TABLE_LEADS . "` ADD KEY `admin_user_idx` (`admin_user_id`)");
		error_log('TajMap: Added admin_user_id column to leads table');
	}
	
	// Check if base_image_transform column exists, if not add it
	$column_exists = $wpdb->get_results($wpdb->prepare(
		"SHOW COLUMNS FROM `" . TAJMAP_PB_TABLE_PLOTS . "` LIKE %s",
		'base_image_transform'
	));
	
	error_log('TajMap: Checking for base_image_transform column, found: ' . count($column_exists) . ' results');
	
	if (empty($column_exists)) {
		$alter_result = $wpdb->query("ALTER TABLE `" . TAJMAP_PB_TABLE_PLOTS . "` ADD COLUMN `base_image_transform` LONGTEXT NULL AFTER `base_image_id`");
		error_log('TajMap: Added base_image_transform column, result: ' . var_export($alter_result, true));
		if ($wpdb->last_error) {
			error_log('TajMap: Database error adding column: ' . $wpdb->last_error);
		}
	} else {
		error_log('TajMap: base_image_transform column already exists');
	}

	$leads_sql = "CREATE TABLE IF NOT EXISTS `" . TAJMAP_PB_TABLE_LEADS . "` (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		plot_id BIGINT UNSIGNED NOT NULL,
		name VARCHAR(191) NULL,
		phone VARCHAR(64) NOT NULL,
		email VARCHAR(191) NULL,
		message TEXT NULL,
		status ENUM('new','contacted','interested','closed') NOT NULL DEFAULT 'new',
		source VARCHAR(50) DEFAULT 'website',
		created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
		PRIMARY KEY (id),
		KEY plot_idx (plot_id),
		KEY status_idx (status),
		KEY email_idx (email)
	) $charset_collate;";
	dbDelta($leads_sql);
	
	// Check if name column exists, if not add it
	$name_column_exists = $wpdb->get_results($wpdb->prepare(
		"SHOW COLUMNS FROM `" . TAJMAP_PB_TABLE_LEADS . "` LIKE %s",
		'name'
	));
	
	if (empty($name_column_exists)) {
		$wpdb->query("ALTER TABLE `" . TAJMAP_PB_TABLE_LEADS . "` ADD COLUMN `name` VARCHAR(191) NULL AFTER `plot_id`");
	}
	
	// Check if email column allows NULL, if not modify it
	$email_column = $wpdb->get_results($wpdb->prepare(
		"SHOW COLUMNS FROM `" . TAJMAP_PB_TABLE_LEADS . "` LIKE %s",
		'email'
	));
	
	if (!empty($email_column) && $email_column[0]->Null === 'NO') {
		$wpdb->query("ALTER TABLE `" . TAJMAP_PB_TABLE_LEADS . "` MODIFY COLUMN `email` VARCHAR(191) NULL");
	}

	$users_sql = "CREATE TABLE IF NOT EXISTS `" . TAJMAP_PB_TABLE_USERS . "` (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		wp_user_id BIGINT UNSIGNED NULL,
		email VARCHAR(191) NOT NULL UNIQUE,
		phone VARCHAR(64) NULL,
		first_name VARCHAR(100) NULL,
		last_name VARCHAR(100) NULL,
		created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
		PRIMARY KEY (id),
		KEY wp_user_idx (wp_user_id),
		KEY email_idx (email)
	) $charset_collate;";
	dbDelta($users_sql);

	$saved_plots_sql = "CREATE TABLE IF NOT EXISTS `" . TAJMAP_PB_TABLE_SAVED_PLOTS . "` (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		user_id BIGINT UNSIGNED NOT NULL,
		plot_id BIGINT UNSIGNED NOT NULL,
		created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
		PRIMARY KEY (id),
		KEY user_idx (user_id),
		KEY plot_idx (plot_id),
		UNIQUE KEY user_plot_idx (user_id, plot_id)
	) $charset_collate;";
	dbDelta($saved_plots_sql);

	$lead_history_sql = "CREATE TABLE IF NOT EXISTS `" . TAJMAP_PB_TABLE_LEAD_HISTORY . "` (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		lead_id BIGINT UNSIGNED NOT NULL,
		user_id BIGINT UNSIGNED NULL,
		action VARCHAR(100) NOT NULL,
		details TEXT NULL,
		created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
		PRIMARY KEY (id),
		KEY lead_idx (lead_id)
	) $charset_collate;";
	dbDelta($lead_history_sql);
});

// Autoload basic includes
require_once TAJMAP_PB_PATH . 'includes/class-tajmap-pb.php';

add_action('plugins_loaded', function () {
	\TajMapPB\Plugin::init();
});
